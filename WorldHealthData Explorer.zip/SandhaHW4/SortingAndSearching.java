
                                       /**************************************************************
                                        ***  Project Name : CS 200 Programming Assignment 4 (HW4)  ***
                                        ***  Author       : Seerat Sandha                          ***
                                        ***  Date         : 11/30/2023                             ***
                                        **************************************************************/     





import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.HashMap;
import java.io.FileNotFoundException;

public class SortingAndSearching
 {
     static Scanner scnr = new Scanner(System.in);
     
   
    public static void main(String[] args) throws IOException {
    BufferedReader readerBuffer = null;

    System.out.println("\n\t\t" + "Welcome to the World Happiness - Corruption Dataset (2015-2020)" + "\n");
    System.out.println("Enter a full pathname and filename for the input file: ");
    String fileName = scnr.nextLine();

    try {
        readerBuffer = new BufferedReader(new FileReader(fileName));

        // Read and process data
        ArrayList<String> headers = readHeaders(readerBuffer);
        ArrayList<ArrayList<String>> data = readData(readerBuffer);
        System.out.println("\n" + "Reading File ......... Done" + "\n");
        System.out.println("Do you wish to (1) Search or (2) Sort by a column? (Enter 1 or 2):");

        // Perform sorting based on user input
        sortSearchAndPrintData(headers, data);
    } catch (FileNotFoundException e) {
        // Handling the case where the file is not found
        System.out.println("The specified file cannot be found. Please check the file path.");
    } catch (IOException e) {
        // Handling other IOExceptions that may occur during file processing
        System.out.println("Error reading the file: " + e.getMessage());
    } finally 
    {
        try 
        {
            if (readerBuffer != null)
            {
                readerBuffer.close();
                
            }
        } catch (IOException readException) {
            System.out.println("Ran into an error reading the file");
            readException.printStackTrace();
        }
    }
}

    
    
// Method to read headers from the CSV file
    private static ArrayList<String> readHeaders(BufferedReader reader) throws IOException {
        String headerLine = reader.readLine();
        return CSVtoArrayList(headerLine);
    }
// Method to read data from the CSV file
    private static ArrayList<ArrayList<String>> readData(BufferedReader reader) throws IOException 
    {
    ArrayList<ArrayList<String>> data = new ArrayList<>();
    // Read the remaining rows
    String inputLine;
    while ((inputLine = reader.readLine()) != null) {
        ArrayList<String> rowData = CSVtoArrayList(inputLine);
        data.add(rowData);

    }
    return data;
    }
// Method to perform merge sort on the data based on a specified column index by user
private static void mergeSort(ArrayList<ArrayList<String>> data, int columnIndex) {
        if (data.size() <= 1) 
        {
            return; // Already sorted
        }

        int middle = data.size() / 2;
        ArrayList<ArrayList<String>> left = new ArrayList<>(data.subList(0, middle));
        ArrayList<ArrayList<String>> right = new ArrayList<>(data.subList(middle, data.size()));

        mergeSort(left, columnIndex);
        mergeSort(right, columnIndex);

        merge(data, left, right, columnIndex);
    }
    

 // Method to merge two halves of the data during the merge sort

    private static void merge(ArrayList<ArrayList<String>> data, ArrayList<ArrayList<String>> left,
        ArrayList<ArrayList<String>> right, int columnIndex) {
    int i = 0, j = 0, k = 0;

    while (i < left.size() && j < right.size()) {
        // Check if indices are within bounds
        if (i < left.size() && j < right.size()) {
            String leftValue = left.get(i).get(columnIndex);
            String rightValue = right.get(j).get(columnIndex);

            // Check for null values
            if (leftValue == null) {
                data.set(k++, right.get(j++));
            } else if (rightValue == null) {
                data.set(k++, left.get(i++));
            } else {
                // Compare non-null values
                if (leftValue.compareTo(rightValue) <= 0) {
                    data.set(k++, left.get(i++));
                } else {
                    data.set(k++, right.get(j++));
                }
            }
        }
    }

    // Handle remaining elements in left and right
    while (i < left.size()) {
        data.set(k++, left.get(i++));
    }

    while (j < right.size()) {
        data.set(k++, right.get(j++));
    }
}


// Method to handle user input for searching or sorting
    private static void sortSearchAndPrintData(ArrayList<String> headers, ArrayList<ArrayList<String>> data) 
    {
        
        Scanner scnr = new Scanner(System.in);
        boolean checkChoice = true;
        boolean columnSelected = false;
        while(checkChoice)
        {
        try 
        {
            String choice = scnr.nextLine();
            choice = choice.toLowerCase();
            
            if(choice.equals("a")||choice.equals("1"))
            {
                  System.out.println("\nSearch Selected"+"\n");
                  System.out.println("Enter the country name: ");
                  String countryInput = scnr.nextLine();
                  
                  System.out.println("Enter the continent ");
                  String continentInput = scnr.nextLine();
                  
                  
                  System.out.println("Enter the year to search by (15-20 inclusive)");
                  String yearInput = scnr.nextLine();
                  
                   
                   if (countryInput.isEmpty())
                  {
                      System.out.println("\nCountry: all");
                  }
                  else
                  {
                      System.out.println("\nCountry: "+ countryInput);
                  }
                  if(continentInput.isEmpty())
                  {
                      System.out.println("Continent:  ");
                  }
                  else
                  {
                       System.out.println("Continent: "+ continentInput);
                  }
                  if(yearInput.isEmpty())
                  {
                      System.out.println("Year: all"+"\n");
                  }
                  else
                  {
                    System.out.println("Year: "+ yearInput+"\n");
                  }
                   
                  
                ArrayList<ArrayList<String>> searchResult = searchData(data, countryInput, continentInput, yearInput);

              // Check if there are matching results
              if (!searchResult.isEmpty())
              {
                   // calling printHeaders to print the data 
                   printHeaders(headers, searchResult, choice);
                   checkChoice = false;
              }
              else
              {
                  System.out.println("Sort by: "+"\n");
                for (int i = 0; i < headers.size(); i++) 
               {
                  System.out.println((char) ('a' + i) + ". " + headers.get(i));
                }
               char columnSelectionInput = getUserCharInput("\nColumn to sort by (a-" + (char) ('a' + headers.size() - 1) + "): ");
                  System.out.println(" no rows returned");
                  checkChoice = false;
              }
            }
                 
            else if (choice.equals("b")||choice.equals("2"))
            {
               // mergeSort(data, columnIndex);
                printHeaders(headers, data, choice);
                checkChoice = false;
            } 
        
    
        else 
        {
                // Add search functionality if needed
                System.out.println("Invalid Input . Enter 1 or 2 only");
                System.out.println("\n"+"Do you wish to (1) Search or (2) Sort by a column? (Enter 1 or 2):");
            
        }
    }

        
        

        catch (InputMismatchException e) 
        {

            
            System.out.println("Invalid input. Please enter a valid option."+"\n");
        }
    }
}


private static char getUserCharInput(String prompt) {
    System.out.print(prompt);
    Scanner scanner = new Scanner(System.in);
    return scanner.nextLine().charAt(0);
}


   private static void printHeaders(ArrayList<String> headers, ArrayList<ArrayList<String>> data, String choice) 
   
   {
    if(choice.equals("2") || choice.equals("b"))
    {
       System.out.println("Sort Selected.\n");
    }
    System.out.println("Sort by: ");
    int columnIndex = 0;
    boolean checkColumnSelection = true; 

    for (int i = 0; i < headers.size(); i++) {
        System.out.println((char) ('a' + i) + ". " + headers.get(i));
    }

   char columnSelectionInput = getUserCharInput("\nColumn to sort by (a-" + (char) ('a' + headers.size() - 1) + "): ");
   char lowercaseSelectionInput = Character.toLowerCase(columnSelectionInput);
   boolean wrongOrderSelection = true;
 
   

    // Check if the input is a valid label
    while(checkColumnSelection)
    {
        
       columnIndex = lowercaseSelectionInput - 'a';
       
    if (lowercaseSelectionInput >= 'a' && lowercaseSelectionInput <= ('a' + headers.size() - 1) )
    {
        if (choice.equals("1") || choice.equals("a"))
        {
           System.out.println("Sorted by " + headers.get(columnIndex));
           if (lowercaseSelectionInput >= 'a' && lowercaseSelectionInput <= ('a' + headers.size() - 1))
           {
            mergeSort(data, columnIndex);
            printData(headers, data); 
            checkColumnSelection = false;
           }
           else
           {
               System.out.println("Sort by: "+"\n");
            for (int i = 0; i < headers.size(); i++) 
            {
               System.out.println((char) ('a' + i) + ". " + headers.get(i));
             }
            columnSelectionInput = getUserCharInput("\nColumn to sort by (a-" + (char) ('a' + headers.size() - 1) + "): ");
            lowercaseSelectionInput = Character.toLowerCase(columnSelectionInput);
           }
        }
        else if(choice.equals("2") || choice.equals("b"))
        {
        System.out.println("Sort by column in (a)scending or (d)escending order: (a-d) ");
        char sortSelectionInput = getUserCharInput("");

        if (sortSelectionInput == 'a')
        {
            System.out.println("Sort in ascending order"+"\n");
            mergeSort(data, columnIndex);
            printData(headers, data);
            checkColumnSelection = false;
        } else if (sortSelectionInput == 'd')
        {
            System.out.println("Sort in descending order"+"\n");
            mergeSort(data, columnIndex);
            Collections.reverse(data); // Reverse the list for descending order
            printData(headers, data);
            checkColumnSelection = false;
        } else 
        {
            wrongOrderSelection = false; 
            System.out.println("\n"+"Invalid input. Please enter a valid column label (a or d)"+"\n");
        }
    }
}
else
{
            System.out.println("Sort by: "+"\n");
            for (int i = 0; i < headers.size(); i++) 
            {
               System.out.println((char) ('a' + i) + ". " + headers.get(i));
             }
            columnSelectionInput = getUserCharInput("\nColumn to sort by (a-" + (char) ('a' + headers.size() - 1) + "): ");
            lowercaseSelectionInput = Character.toLowerCase(columnSelectionInput);
}
}
}




    private static void printData(ArrayList<String> headers, ArrayList<ArrayList<String>> data)
    {
        // Print headers
        for (String header : headers) {
            System.out.printf("%-23s",header);
        }
        System.out.println();

        // Assuming data is a List<ArrayList<String>> containing numerical data
    for (ArrayList<String> row : data)
    {
         for (int j = 0; j < row.size(); j++) {
        String cell = row.get(j);

        // Convert and format numerical values to two decimal places
        if (j >= 3 && j < 11) {
            try {
                double numericValue = Double.parseDouble(cell);
                String formattedValue = String.format("%.2f", numericValue);
                System.out.printf("%-23s", formattedValue);
            } catch (NumberFormatException e) {
               
                System.out.printf("%-23s", cell);
            }
        } else 
        {
            // Print non-numeric values as they are
            System.out.printf("%-23s", cell);
        }
        }
    System.out.println(); // Moving to the next line after printing a row
    }

}

    private static ArrayList<String> CSVtoArrayList(String CSVFileName) {
    // This ArrayList will hold the individual values from a CSV row
    ArrayList<String> arrlist = new ArrayList<>();

    if (CSVFileName != null) {
        String[] splitData = CSVFileName.split(",", -1); // The -1 helps handle null values

        for (int i = 0; i < splitData.length; i++) {
            // If it is null, replace it with "0"
            if (splitData[i].length() == 0) {
                splitData[i] = "0";
            }

            // As long as it is not null and the length is not 0, trim the value and add it to the ArrayList
            if (splitData[i] != null && splitData[i].length() != 0) {
                if (i > 2) 
                {
    try
     {
        // Try parsing as float, and add it as a string
        arrlist.add(Double.toString(Double.parseDouble(splitData[i].trim())));
    } catch (NumberFormatException e) {
        // Handle non-numeric values by adding them as strings
        arrlist.add(splitData[i].trim());
    }
    } 
  else
   {
    // Add other values as strings
    arrlist.add(splitData[i].trim());
    }
            }
        }
    }
    return arrlist;
}
    
   private static ArrayList<ArrayList<String>> searchData(ArrayList<ArrayList<String>> data, String countryInput, String continentInput, String yearInput) {
    ArrayList<ArrayList<String>> searchDataResult = new ArrayList<>();

    for (int i = 0; i < data.size(); i++) {
        String countryName = data.get(i).get(0);
        String yearValue = data.get(i).get(1);
        String continentName = data.get(i).get(2);
        int StringYearIntoNumber = Integer.parseInt(yearValue);
        int lastTwoDigits = StringYearIntoNumber%100;
        countryInput = countryInput.toLowerCase();
        
        yearInput = yearInput.toLowerCase();
        
        String lowercountryName = countryName.toLowerCase();
        
        if ((countryInput.isEmpty() || lowercountryName.equals(countryInput))
    && (continentInput.isEmpty() || continentName.equalsIgnoreCase(continentInput))
    && (yearInput.isEmpty() || Integer.parseInt(yearInput) == lastTwoDigits)) 


        {

            // Add the matching data to the result list
            ArrayList<String> match = new ArrayList<>();
            continentName = continentName.toUpperCase();
            match.add(countryName);
            match.add(yearValue);
            match.add(continentName);
            for (int j = 3; j < 11; j++) {
                match.add(data.get(i).get(j));
            }
            searchDataResult.add(match);
        }
    }

    return searchDataResult;
}



}
         
         
   



